java -jar /myapp-0.0.1.jar
